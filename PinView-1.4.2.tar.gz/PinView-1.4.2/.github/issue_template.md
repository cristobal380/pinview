What kind of issue is this?

 - [ ] Question. If you want to ask how to do something, or to understand why something isn't
       working the way you expect it to.

 - [ ] Bug report. Please provide your device name, device OS version, and describe the reproduction steps.

 - [ ] Feature Request. Telling us what problem you’re trying to solve.

##### Info:

 * PinView version:
 * Device OS version:
 * Device Name:

##### Description:

##### Reproduction Steps:

##### What did I do: